document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");

    form.addEventListener("submit", (e) => {
        const password = document.getElementById("password").value;
        if (password.length < 6) {
            e.preventDefault();
            alert("Пароль должен содержать минимум 6 символов.");
        }
    });
});
